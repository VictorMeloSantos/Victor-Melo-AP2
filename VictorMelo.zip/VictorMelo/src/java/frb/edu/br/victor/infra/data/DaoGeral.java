
package frb.edu.br.victor.infra.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;


public abstract class DaoGeral {
    
    private Connection connection = null;
    
    public Connection getConnection() throws ClassNotFoundException, SQLException{
        // metodo responsavel por abrir a conecxao com o banco
        if(this.connection == null){
            
            String url="jdbc:mysql://localhost:3306/ap2?zeroDateTimeBehavior=convertToNull";
            String senha="root";
            String user="root";
            String driver="com/mysql/jdbc/Driver";
            
            Class.forName(driver);
            connection= DriverManager.getConnection(url, user, senha); 
        }
        return connection;
    }
    
    
    public void getFechaConnection() throws SQLException{
        // metodo criado para fechar a conecxao com o banco
        if(this.connection!= null){
            this.connection.close();
            this.connection = null;
        }
        
    }
    public Statement getStatement() throws ClassNotFoundException, SQLException{
        return this.getConnection().createStatement();
        
        
    }
    
    public PreparedStatement getPreparedStatement(String sql) throws ClassNotFoundException, SQLException{
        return this.getConnection().prepareStatement(sql);
        
        
    }
    
    
    
}