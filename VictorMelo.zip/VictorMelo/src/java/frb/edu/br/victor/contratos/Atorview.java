
package frb.edu.br.victor.contratos;

import frb.edu.br.victor.entidades.AtorDTO;
import java.util.List;


public interface Atorview {
   
    boolean incluir(AtorDTO ator);
    boolean alterar(AtorDTO ator);
    boolean deletar (int id);
    AtorDTO getRegistroID(int id);
    List<AtorDTO>getLisTaodos();
}
