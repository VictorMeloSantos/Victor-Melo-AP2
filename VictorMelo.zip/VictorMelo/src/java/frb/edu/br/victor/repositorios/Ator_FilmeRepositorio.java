/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frb.edu.br.victor.repositorios;

import frb.edu.br.victor.entidades.Ator_FilmeDTO;
import frb.edu.br.victor.infra.data.DaoGeral;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import frb.edu.br.victor.contratos.Filme_AtorView;

public class Ator_FilmeRepositorio extends DaoGeral implements Filme_AtorView{

    public Ator_FilmeRepositorio() {
        // este construtor serve para ativar a class DaoUltil
        super();
    }
 
    @Override
    public boolean incluir(Ator_FilmeDTO filmeator) {
    String sql="INSERT INTO filme_ator(ator_id,filme_id,ultimaatualizacao)"+
                "VALUES(?,?,?,?,?,?,?)";
        PreparedStatement ps;
        int ret=-1;
        try {
            ps = super.getPreparedStatement(sql); // responsavel por fazer a coneção, vem da classe dao
             ps.setInt(1,filmeator.getIdAtor_filme());
             ps.setInt(2,filmeator.getIdFilme());
             ps.setDate(3, new java.sql.Date(filmeator.getUltimaatualizacao().getTime()));// como o java nao ultiliza a mesma linguagem para data tem que transforma a date do java para o date do banco , para que possa ser interpretado.
             ret= ps.executeUpdate(); // aqui vai me retorna um inteiro infomando quanttas incersoes foram feitas
             ps.close();
            
             
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ret>0;
  
    }

    @Override
    public boolean alterar(Ator_FilmeDTO ator_filme) {
        String sql="UPDADTE  filme_ator SET ultima_atualizacao=?"+
                "WHERE idendereco=?";
        PreparedStatement ps;
        int ret=-1;
        try {
            ps = super.getPreparedStatement(sql); 
          
             ps.setInt(1, ator_filme.getIdAtor_filme());
             ret= ps.executeUpdate(); 
             ps.close();
                     
             
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ret>0;
    }

    @Override
    public boolean deletar(int id) {
         String sql="DELETE FROM  filme_ator "+"WHERE filme_id=?";
        PreparedStatement ps;
        int ret=-1;
        try {
            ps = super.getPreparedStatement(sql); 
              
             ps.setInt(1,id);
             ret= ps.executeUpdate(); 
             ps.close();
                        
             
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ret>0;
    }

    @Override
    public Ator_FilmeDTO getRegistroID(int id) {
        Ator_FilmeDTO atoor= new Ator_FilmeDTO();
        
        String sql="SELECT ator_id, filme_id,ultima_atualizacao";
        sql += "Where filme_id=?";
        try {
            PreparedStatement ps=super.getPreparedStatement(sql);
            ps.setInt(1, id);
            ResultSet resul=ps.executeQuery();
            while(resul.next()){
                atoor = new Ator_FilmeDTO(resul.getInt("idendereco"), 
                        resul.getInt("filme_id"), 
                        resul.getInt("ator_id"), 
                        resul.getString("ultima_atualizacao"));                  
            }
            resul.close();
            ps.close();
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return atoor;
    }

    @Override
    public List<Ator_FilmeDTO> getLisTaodos() {
     List <Ator_FilmeDTO> atoress= new LinkedList<>();
        
        String sql="SELECT ator_id, filme_id, ultima_atualizacao";

        try {
            PreparedStatement ps = super.getPreparedStatement(sql);           
            ResultSet resul=ps.executeQuery();
            while(resul.next()){
                
                atoress.add (new Ator_FilmeDTO(resul.getInt("ator_id"), 
                        resul.getInt("ator_id"),
                        resul.getInt("filme_id"), 
                        resul.getString("ultima_atualizacao")));                  
            }
            resul.close();
            ps.close();
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return atoress;
    }
    
}
