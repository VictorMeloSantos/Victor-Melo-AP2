
package frb.edu.br.victor.contratos;

import frb.edu.br.victor.entidades.Ator_FilmeDTO;
import java.util.List;

public interface Filme_AtorView {
    
    boolean incluir(Ator_FilmeDTO ator_filme);
    boolean alterar(Ator_FilmeDTO ator_filme);
    boolean deletar (int id);
    Ator_FilmeDTO getRegistroID(int id);
    List<Ator_FilmeDTO>getLisTaodos();
    
    
}
