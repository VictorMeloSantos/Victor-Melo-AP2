/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frb.edu.br.victor.repositorios;


import frb.edu.br.victor.entidades.AtorDTO;
import frb.edu.br.victor.infra.data.DaoGeral;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import frb.edu.br.victor.contratos.Atorview;

public class AtorRepositorio extends DaoGeral implements Atorview{

  
        public AtorRepositorio() {
        // este construtor serve para ativar a class DaoGeral
        super();
    }
 
    @Override
    public boolean incluir(AtorDTO ator) {
    String sql="INSERT INTO ator(ator_id,primeiro_nome,ultimo_nome,ultima_atualizacao)"+
                "VALUES(?,?,?,?)";
        PreparedStatement ps;
        int ret=-1;
        try {
            ps = super.getPreparedStatement(sql); 
             ps.setInt(1,ator.getIdAtor());
             ps.setString(2, ator.getPrimeironome());
             ps.setString(3,ator.getUltimonome());
             ps.setDate(4, new java.sql.Date(ator.getUltimaAtualizacao().getTime()));
             ret= ps.executeUpdate(); 
             ps.close();
         
             
             
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ret>0;
  
    }

    @Override
    public boolean alterar(AtorDTO ator) {
        String sql="UPDADTE  ator SET primeiro_nome=?,ultimo_nome=?,ultima_atualizacao=?"+
                "WHERE ator_id=?";
        PreparedStatement ps;
        int ret=-1;
  try {
            ps = super.getPreparedStatement(sql); 
             ps.setString(1, ator.getPrimeironome());
             ps.setString(2,ator.getUltimonome());
             ps.setDate(3, new java.sql.Date(ator.getUltimaAtualizacao().getTime()));
             ret= ps.executeUpdate(); 
             ps.close();
       
             
             
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ret>0;
    }

    @Override
    public boolean deletar(int id) {
         String sql="DELETE FROM  ator  "+"WHERE ator_id=?";
        PreparedStatement ps;
        int ret=-1;
        try {
            ps = super.getPreparedStatement(sql); 
              
             ps.setInt(1,id); 
             ret= ps.executeUpdate(); 
             ps.close();
                        
             
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AtorRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(AtorRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ret>0;
    }

    @Override
    public AtorDTO getRegistroID(int id) {
        AtorDTO cidad= new AtorDTO();
        
        String sql="SELECT ator_id, primeiro_nome,ultimo_nome,ultima_atualizacao";
        sql += "Where ator_id=?";
        try {
            PreparedStatement ps=super.getPreparedStatement(sql);
            ps.setInt(1, id);
            ResultSet resul=ps.executeQuery();
            while(resul.next()){
                AtorDTO atorr = new AtorDTO(resul.getInt("ator_id"), 
                        resul.getString("primeiro_nome"), 
                        resul.getArray("ultimo_nome"),
                        resul.getDate("ultima_atualizacao"));                  
            }               
            resul.close();
            ps.close();
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cidad;
    }

    @Override
    public List<AtorDTO> getLisTaodos() {
     List <AtorDTO> atorr= new LinkedList<>();
        
        String sql="SELECT ator_id, primeiro_nome,ultimo_nome,ultima_atualizacao";

        try {
            PreparedStatement ps = super.getPreparedStatement(sql);           
            ResultSet resul=ps.executeQuery();
            while(resul.next()){
          
                atorr.add (new AtorDTO(resul.getInt("ator_id"), 
                        resul.getString("primeiro_nome"), 
                        resul.getArray("ultimo_nome"), 
                        resul.getDate("ultima_atualizacao")));          
        
   
            }
            resul.close();
            ps.close();
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ator_FilmeRepositorio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return atorr;
    }
    
    
    
    
    

 
}
