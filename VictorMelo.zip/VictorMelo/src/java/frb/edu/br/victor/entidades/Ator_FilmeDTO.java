

package frb.edu.br.victor.entidades;

import java.util.Date;


public class Ator_FilmeDTO {
    
    
  private int idAtor_filme;
  private int idFilme;
  
  private Date ultimaatualizacao;

    public Ator_FilmeDTO() {
    }

    public Ator_FilmeDTO(int aInt, int aInt0, int aInt1, String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getIdAtor_filme() {
        return idAtor_filme;
    }

    public void setIdAtor_filme(int idAtor_filme) {
        this.idAtor_filme = idAtor_filme;
    }

    public int getIdFilme() {
        return idFilme;
    }

    public void setIdFilme(int idFilme) {
        this.idFilme = idFilme;
    }

    public Date getUltimaatualizacao() {
        return ultimaatualizacao;
    }

    public void setUltimaatualizacao(Date ultimaatualizacao) {
        this.ultimaatualizacao = ultimaatualizacao;
    }

}