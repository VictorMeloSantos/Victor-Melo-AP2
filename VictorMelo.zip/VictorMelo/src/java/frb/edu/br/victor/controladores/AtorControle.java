
package frb.edu.br.victor.controladores;


import frb.edu.br.victor.entidades.AtorDTO;
import frb.edu.br.victor.repositorios.AtorRepositorio;
import java.util.List;


public class AtorControle {
     private AtorDTO ator;
    private List<AtorDTO> atores = null;
    
    private  AtorRepositorio atorRepositorio = new AtorRepositorio();
    
    
    
    public AtorControle() {
    }

    public AtorDTO getAtor() {
        return ator;
    }

    public void setAtor(AtorDTO ator) {
        this.ator = ator;
    }

    public List<AtorDTO> getAtores() {
        if(atores == null){
            
            atores = atorRepositorio.getLisTaodos();
        }
        return atores;
    }
    
    public String prepararInclusao(){
        
        ator = new AtorDTO();
        return "irParaAtorIncluir";
    }
    
    public String   finalizarInclusao(){
        atorRepositorio.incluir(ator);
        ator = null;
        return "voltaParaListagem";
    }
    
    
    public String finalizaEdicao(){
        atorRepositorio.alterar(ator);
        ator=null;
        
        return "voltaParaListagem";
    }
    
    public String finalizaDelecao(){
        
        atorRepositorio.deletar(ator.getIdAtor());
    
    return "refresh";
    }
    
    
    
}

