
package frb.edu.br.victor.controladores;

import frb.edu.br.victor.entidades.Ator_FilmeDTO;
import frb.edu.br.victor.repositorios.Ator_FilmeRepositorio;
import java.util.List;


public class Ator_FilmeController {

   
    private Ator_FilmeDTO ator_filme;
    private List<Ator_FilmeDTO> ator_filmes = null;
    
    private Ator_FilmeRepositorio ator_filmeRepositorio = new Ator_FilmeRepositorio();
    
    
    
    public Ator_FilmeController() {
    }

    public Ator_FilmeDTO getEndereco() {
        return ator_filme;
    }

    public void setEndereco(Ator_FilmeDTO endereco) {
        this.ator_filme = ator_filme;
    }

    public List<Ator_FilmeDTO> getEnderecos() {
        if(ator_filmes == null){
            
            ator_filmes = ator_filmeRepositorio.getLisTaodos();
        }
        return ator_filmes;
    }
    
    public String prepararInclusao(){
        
        ator_filme = new Ator_FilmeDTO();
        return "irParaAtor_FilmesIncluir";
    }
    
    public String  finalizarInclusao(){
        ator_filmeRepositorio.incluir(ator_filme);
        ator_filmes = null;
        return "voltaParaListagem";
    }
    
    
    public String finalizaEdicao(){
        ator_filmeRepositorio.alterar(ator_filme);
        ator_filme=null;
        
        return "voltaParaListagem";
    }
    
    public String finalizaDelecao(){
        
        ator_filmeRepositorio.deletar(ator_filme.getIdAtor_filme());
    
    return "refresh";
    }
    
    
    
    
    
    
}
